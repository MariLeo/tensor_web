import React, { Component } from 'react';
import './App.css';
import Nav from './Nav';
import './bootstrap.min.css';
import {Navbar, Form, Button, Card} from 'react-bootstrap';


const Home = () => (
    <div>
        <h1> Welcome to the Tornadoes Website!</h1>
    </div>
);

export default Home;
