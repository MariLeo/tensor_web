class  Note {
    constructor(message){
        this.note = message;
    }
}

export default Note;