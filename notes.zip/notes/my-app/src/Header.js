import React, { Component } from 'react';
import './App.css';
import Nav from './Nav';
import './bootstrap.min.css';
import {Navbar, Form, Button} from 'react-bootstrap';



class Header  extends  Component{
    render(){
        return(
            <Nav/>
        );
    }
}

export default Header;